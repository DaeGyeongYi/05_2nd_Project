# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

from django import template
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse

import csv
from django.shortcuts import render
import os
import pandas as pd
import json
import logging
@login_required(login_url="/login/")
def index(request):


    context = {'segment': 'index'}

    html_template = loader.get_template('index.html')
    return HttpResponse(html_template.render(context, request))


@login_required(login_url="/login/")
def pages(request):
    # 지역 csv
    region = pd.read_csv('C:\env\Final_CSV\지역.csv\part-00000-d70adea7-1934-4300-afaa-f8ed7ff2fa29-c000.csv')
    region['법정동'] = region['시도명'] + ' ' + region['법정동명']
    # 고등학교 csv
    high = pd.read_csv('C:\env\Final_CSV\고등학교.csv\part-00000-0b88bc1e-b1ea-4cc2-912c-7229d33fd7b5-c000.csv')
    high = pd.merge(high, region, left_on='주소', right_on='법정동', how='left')
    h1 = high.groupby('학교종류').sum()
    h2 = high.groupby('시도명').sum()
    h1_labels = list(h1.index)
    h1_data = list(h1['서울대합격자수'])
    h2_labels = list(h2.index)
    h2_data = list(h2['서울대합격자수'])


    # 중학교 csv
    middle = pd.read_csv(
        'C:\env\Final_CSV\중학교.csv\part-00000-3f0c90f1-cb8b-4cf9-9df1-397bad86bfa4-c000.csv'
    )
    middle=pd.merge(middle, region, left_on='주소', right_on='법정동',how='left')
    middle = middle.groupby('시도명').sum()
    m_labels = list(middle.index)
    m_data = list(middle['특목고진학자수'])


    # 교육청 csv
    office = pd.read_csv(
        'C:\env\Final_CSV\교육청.csv\part-00000-d7c2b366-2591-45be-a27a-41bf85da0021-c000.csv'
    )
    office_labels = list(office['시도명'])
    office_data = list(office['예산'])

    # # 학군 csv
    study_region = pd.read_csv(
        'C:\env\Final_CSV\학군.csv\part-00000-7bd95b49-28a0-4203-bd5d-d95ac1c69268-c000.csv'
    )
    s_r=pd.merge(study_region, region, on='법정동코드',how='left')
    s_r1 = s_r.groupby('시도명').sum()
    s_r1_labels = list(s_r1.index)
    s_r1_data = list(s_r1['중학교학업중단자수'])
    s_r2_data = list(s_r1['고등학교학업중단자수'])
    s_r3_data = list(s_r1['중등학령인구'])


    #
    # # 지하철 csv
    # sub = pd.read_csv(
    #     'C:\env\Final_CSV\지하철.csv\part-00000-d7c2b366-2591-45be-a27a-41bf85da0021-c000.csv')
    # s_labels = list(sub['시도명'])
    # s_data = list(sub['예산'])


    # 강사 csv
    # teacher = pd.read_csv(
    #     'C:\env\Final_CSV\강사.csv\part-00000-d7c2b366-2591-45be-a27a-41bf85da0021-c000.csv',
    #     'C:\env\Final_CSV\강사.csv\part-00001-a48377cd-fce2-4f46-b528-2c333b27f1ae-c000.csv')
    # teacher =teacher.groupby('').count()
    # teacher_labels = list(teacher.index)
    # teacher_data = list(teacher['success'])

    # 학원 csv
    # aca = pd.read_csv(
    #     'C:\env\Final_CSV\강사.csv\part-00000-d7c2b366-2591-45be-a27a-41bf85da0021-c000.csv',
    #     'C:\env\Final_CSV\강사.csv\part-00001-a48377cd-fce2-4f46-b528-2c333b27f1ae-c000.csv')
    # aca =aca.groupby('').count()
    # aca_labels = list(aca.index)
    # aca_data = list(aca['success'])




    context = {'h2_labels': h2_labels, 'h2_data': h2_data,
               'h1_labels': h1_labels, 'h1_data': h1_data,
                'm_labels': m_labels, 'm_data': m_data,
                'office_labels': office_labels, 'office_data': office_data,
               's_r1_labels':s_r1_labels, 's_r1_data':s_r1_data, 's_r2_data':s_r2_data,'s_r3_data':s_r3_data
               # 'teacher_labels' :teacher_labels,'teacher_data':teacher_data,
               # 'aca_labels': aca_labels, 'aca_data':aca_data
                }


    # All resource paths end in .html.
    # Pick out the html file name from the url. And load that template.
    try:

        load_template = request.path.split('/')[-1]

        if load_template == 'admin':
            return HttpResponseRedirect(reverse('admin:index'))
        context['segment'] = load_template

        html_template = loader.get_template(load_template)
        return HttpResponse(html_template.render(context, request))

    except template.TemplateDoesNotExist:

        html_template = loader.get_template('page-404.html')
        return HttpResponse(html_template.render(context, request))

    except:
        html_template = loader.get_template('page-500.html')
        return HttpResponse(html_template.render(context, request))

