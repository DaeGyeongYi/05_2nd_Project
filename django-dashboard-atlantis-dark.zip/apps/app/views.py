# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

from django import template
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
import csv
from django.shortcuts import render
import os
import pandas as pd
import json
import logging
@login_required(login_url="/login/")
def index(request):
    context = {'segment': 'index'}

    html_template = loader.get_template('index.html')
    return HttpResponse(html_template.render(context, request))


@login_required(login_url="/login/")
def pages(request):
    high= pd.read_csv('C:\env\high.csv')
    high_labels =list(high['region'])
    high_data=list(high['success'])
    context ={'high_labels':high_labels, 'high_data':high_data }


    # All resource paths end in .html.
    # Pick out the html file name from the url. And load that template.
    try:

        load_template = request.path.split('/')[-1]

        if load_template == 'admin':
            return HttpResponseRedirect(reverse('admin:index'))
        context['segment'] = load_template

        html_template = loader.get_template(load_template)
        return HttpResponse(html_template.render(context, request))

    except template.TemplateDoesNotExist:

        html_template = loader.get_template('page-404.html')
        return HttpResponse(html_template.render(context, request))

    except:
        html_template = loader.get_template('page-500.html')
        return HttpResponse(html_template.render(context, request))


# def dash1(request) :
#     # 행정구역별 고등학교
#
#     high =pd.read_csv('C:\env\high.csv')
#     template = loader.get_template('charts.html')
#     ash_labels =list(high['reg'])
#     ash_labels = list(high['reg'])
#
#
#     # dashboard_res =json.dumps(dash_dict)
#
#     return render(request, 'charts.html',{'g_labels' :g_labels,
#                                           'g_values':g_values})

# def chart_data(request):
#     data = []
#     labels=[]
#     df = pd.read_csv("sub.csv")
#     data = df['count'].values
#     labels =df['주소'].values
#
#     return render(request, 'charts.html',
#                       {
#                           'data': json.dumps(data),
#                           'labels': json.dumps(labels)
#                       })